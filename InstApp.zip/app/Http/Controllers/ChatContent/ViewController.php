<?php

namespace App\Http\Controllers\ChatContent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    //
}
