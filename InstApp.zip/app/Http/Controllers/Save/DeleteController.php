<?php

namespace App\Http\Controllers\Save;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DeleteController extends Controller
{
    //
}
